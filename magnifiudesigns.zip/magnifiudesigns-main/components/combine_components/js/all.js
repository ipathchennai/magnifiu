
/*fill blank js start*/
$(document).ready(function () {
    function makedraggable() {
        $(".option-item").draggable({
            "revert": "invalid"
        });
    }
    makedraggable();
    $(".drop-element").droppable({
        "accept": ".option-item",
        "drop": function (event, ui) {
            if ($(this).find(".option-item").length) {
                var $presentChild = $(this).find(".option-item"),
                    currChildId = $presentChild.attr("id"),
                    $currChildContainer = $("#" + currChildId + "-container");
                $currChildContainer.append($presentChild);
                $presentChild.removeAttr("style");
                makedraggable();
            }
            $(this).addClass('dropped');
            $(ui.draggable).clone().appendTo(this).removeAttr("style");
            $(ui.draggable).remove();
        },
    })
    $.ui.draggable.prototype.destroy = function (ul, item) { };
})
/*fill blank js end*/

/*drag and drop js start*/
$(init);
function init() {
    $(".drag-drop-area").sortable({
        connectWith: ".connected-sortable",
        stack: '.connected-sortable ul'
    }).disableSelection();
}
/*drag and drop js end*/

/*sorting js start*/
function sortUsingNestedText(parent, childSelector, keySelector) {

    var items = parent.children(childSelector).sort(function (a, b) {
        console.log(parent, childSelector, keySelector);
        var vA = $(keySelector, a).text();
        var vB = $(keySelector, b).text();
        return (vA < vB) ? -1 : (vA > vB) ? 1 : 0;
    });
    parent.append(items);
}

/* setup sort attributes */
$('#sort_btn').data("sortKey", "div .option");

/* sort on button click */
$("button.btnSorts").click(function () {

    sortUsingNestedText($('#sortUl'), "div", $(this).data("sortKey"));
});



$(document).ready(function () {

    function makedraggable() {
        $(".sort-item").draggable({
            "revert": true

        });
    }

    makedraggable();
    $(".sort-drop-element").droppable({
        "accept": ".sort-item",
        "drop": function (event, ui) {
            if ($(this).find(".sort-item").length) {
                var $presentChild = $(this).find(".sort-item"),
                    currChildId = $presentChild.attr("id"),
                    $currChildContainer = $("#" + currChildId + "-container");
                $currChildContainer.append($presentChild);
                $presentChild.removeAttr("style");
                makedraggable();
            }
            $(this).addClass('dropped');
            $(ui.draggable).clone().appendTo(this).removeAttr("style");
            $(ui.draggable).remove();

        },
    })
    $.ui.draggable.prototype.destroy = function (ul, item) { };
})
/*sorting js end*/

/*slider js start*/
$(function () {
    var valMap = ['end point', 'point', 'center', 'point', 'end point'];

    $("#slider").slider({
        max: valMap.length - 1,
        slide: function (event, ui) {
            $("#radiusAmount").val(valMap[ui.value]);
        }
    })
        .each(function () {
            var opt = $(this).data().uiSlider.options;
            var vals = opt.max - opt.min;
            var arrayLength = valMap.length;
            for (var i = 0; i < arrayLength; i++) {
                var el = $('<label>' + (valMap[i]) + '</label>').css('left', (i / vals * 100) + '%');
                $("#slider").append(el);
            }
        });
});
/*slider js end*/


/*file upload js start*/
Dropzone.autoDiscover = false;

var $dropZone = $("#mydropzone").dropzone({
    url: "/",
    acceptedFiles: '.mp4, .mp3'

    /*options*/
});
$(document).ready(function () {
    console.log($dropZone[0].dropzone.files)
});
/*file upload js end*/

/*bootstrap file upload start */
$('#inputGroupFile02').on('change',function(){
    //get the file name
    var fileName = $(this).val();
    //replace the "Choose a file" label
    $(this).parent().prev().html(fileName);
    $('.upload-checkbox').removeClass('d-none');
})
/*bootstrap file upload end */

/*multi choice search js start*/
 $(window).on('load', function () {
    console.log($('.is-options-list li').attr('data-option-value'))
    $("#search-criteria").on("keyup", function () {
        var g = $(this).val().toLowerCase();
        $("#linguagens .is-options-list .list-picker-list-item").each(function () {
            var s = $(this).children().children().children().text().toLowerCase();
            $(this)[s.indexOf(g) !== -1 ? 'show' : 'hide']();
        });
    });
});

/*multi choice search js end */


/*textarea js start*/
$(".arrow-down").on("click", function () {
    $(document).ready(function () {
        var $textarea = $('#update');
        $textarea.scrollTop($textarea[0].scrollHeight);
    });
});
$(".arrow-up").on("click", function () {
    $(document).ready(function () {
        var $textarea = $('#update');
        $textarea.scrollTop(0);
    });
});
/*textarea js end*/


/*select dropdown js start*/
$('select').each(function () {
    var $this = $(this), selectOptions = $(this).children('option').length;

    $this.addClass('hide-select');
    $this.wrap('<div class="select"></div>');
    $this.after('<div class="custom-select"></div>');

    var $customSelect = $this.next('div.custom-select');
    $customSelect.text($this.children('option').eq(0).text());

    var $optionlist = $('<ul />', {
        'class': 'select-options'
    }).insertAfter($customSelect);

    for (var i = 0; i < selectOptions; i++) {
        $('<li />', {
            text: $this.children('option').eq(i).text(),
            rel: $this.children('option').eq(i).val()
        }).appendTo($optionlist);
    }

    var $optionlistItems = $optionlist.children('li');

    $customSelect.click(function (e) {
        e.stopPropagation();
        $('div.custom-select.active').not(this).each(function () {
            $(this).removeClass('active').next('ul.select-options').hide();
        });
        $(this).toggleClass('active').next('ul.select-options').slideToggle();
    });

    $optionlistItems.click(function (e) {
        e.stopPropagation();
        $customSelect.text($(this).text()).removeClass('active');
        $this.val($(this).attr('rel'));
        $optionlist.hide();
    });

    $(document).click(function () {
        $customSelect.removeClass('active');
        $optionlist.hide();
    });

});
/*select dropdown js end */

/* star rating 2 js start */
jQuery(document).ready(function($) {
    $('.rating .star').hover(function() {
      $(this).addClass('to_rate');
      $(this).parent().find('.star:lt(' + $(this).index() + ')').addClass('to_rate');
      $(this).parent().find('.star:gt(' + $(this).index() + ')').addClass('no_to_rate');
    }).mouseout(function() {
      $(this).parent().find('.star').removeClass('to_rate');
      $(this).parent().find('.star:gt(' + $(this).index() + ')').removeClass('no_to_rate');
    }).click(function() {
      $(this).removeClass('to_rate').addClass('rated');
      $(this).parent().find('.star:lt(' + $(this).index() + ')').removeClass('to_rate').addClass('rated');
      $(this).parent().find('.star:gt(' + $(this).index() + ')').removeClass('no_to_rate').removeClass('rated');
    });
});
/* star rating 2 js end */
