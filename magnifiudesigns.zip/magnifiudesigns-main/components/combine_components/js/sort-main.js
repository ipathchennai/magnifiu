function e() {
    var e, l;
    e = '<div id="sort_order" class="list-picker">', e += ' <div class="card-container"> <p class="w-100 d-flex flex-wrap drop-text">Place these in your prefered order above</p> <ul class="sort-list-picker-list sort-is-options-list"></ul></div>';
    for (var r = 0; r < c; r++) e += ' <div class="picks-container"><ul class="sort-list-picker-list sort-is-picks-list"></ul> <button id="" class="save mt-4 btn">Save Answer</button></div>';
    e += "</div>", document.querySelector(".data").style.display = "none", document.querySelector("#multi_fill").innerHTML = e, l = {
        list: ["Options 1", "Options 2", "Options 3", "Options 4", "Options 5", "Options 6", "Options 7"],
        gap: 1,
        drag: s,
        fixed: t,
        order: i,
        template: function (e, s) {
            var t = '<div class="card">';
            return t += ' <div class="card-close">', t += '   <span class="card-close-icon card-close-plus"><i class="fas fa-ellipsis-v"></i><i class="fas fa-ellipsis-v"></i></span></div>', t += '  <div class="close-minus"> <span class="card-close-icon card-close-times">&times;</span>', t += " </div>", t += ' <div class="card-content">', t += '   <p class="card-content-text">' + s + "</p>", t += " </div>", t += "</div>"
        }
    }, d = new ListPicker("#sort_order", l)
}
var s = 1,
    t = !1,
    c = 1,
    i = !0,
    d = null,
    l = document.querySelector("#select"),
    r = document.querySelector("#drag"),
    a = document.querySelector("#order"),
    n = document.querySelector("#keep"),
    o = document.querySelector("#loose"),
    u = document.querySelector("#fixed"),
    v = document.querySelector("#remove"),
    m = document.querySelector("#add"),
    L = document.querySelector("#return");
l.addEventListener("click", function (c) {
    t || (s = !1, l.classList.add("is-selected"), r.classList.remove("is-selected"), e())
}), r.addEventListener("click", function (c) {
    t || (s = !0, l.classList.remove("is-selected"), r.classList.add("is-selected"), e())
}), a.addEventListener("click", function (s) {
    t || (i = !0, a.classList.add("is-selected"), n.classList.remove("is-selected"), e())
}), n.addEventListener("click", function (s) {
    t || (i = !1, a.classList.remove("is-selected"), n.classList.add("is-selected"), e())
}), o.addEventListener("click", function (s) {
    t = !1, o.classList.add("is-selected"), u.classList.remove("is-selected"), l.removeAttribute("disabled"), r.removeAttribute("disabled"), a.removeAttribute("disabled"), n.removeAttribute("disabled"), e()
}), u.addEventListener("click", function (c) {
    s = !1, t = !0, l.classList.add("is-selected"), r.classList.remove("is-selected"), o.classList.remove("is-selected"), u.classList.add("is-selected"), l.setAttribute("disabled", "disabled"), r.setAttribute("disabled", "disabled"), a.setAttribute("disabled", "disabled"), n.setAttribute("disabled", "disabled"), e()
}), v.addEventListener("click", function (s) {
    c > 1 && c--, e()
}), m.addEventListener("click", function (s) {
    c < 3 && c++, e()
}), L.addEventListener("click", function (e) {
    for (var s = document.querySelector(".data"), t = s.querySelector("code"), c = d.getPicks(), i = "[\n", l = 0; l < c.length; l++) i += "  " + l + ": [" + c[l] + "]\n";
    i += "]", s.style.display = "block", t.textContent = i
}), e();