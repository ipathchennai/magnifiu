


$('#done-btn').click(function(){
    $('#done-btn').addClass('d-none');
    $('#lastprocess').removeClass('d-none');
    var value = 50;
    $(".track-data").attr("data-percentage", value.toString());
});

$("#textbox-msg").keyup(function(){
    var text = $("textarea#textbox-msg").val();
    if(text != ""){
        var value = 100;
        $(".track-data").attr("data-percentage", value.toString());
        $("#form-error").addClass('d-none');
        $("#form-ok").removeClass('d-none');
        $("#form-error1").addClass('d-none');
        $("#form-ok1").removeClass('d-none');
    }
    else{
        var value = 50;
        $(".track-data").attr("data-percentage", value.toString());
        $("#form-ok").addClass('d-none');
        $("#form-error").removeClass('d-none');
        $("#form-ok1").addClass('d-none');
        $("#form-error1").removeClass('d-none');
    }

});    
