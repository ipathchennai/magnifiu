// step 1

$('input[type="range"]').on('input', function() {

    var control = $(this),
    controlMin = control.attr('min'),
    controlMax = control.attr('max'),
    controlVal = control.val(),
    controlThumbWidth = control.data('thumbwidth');

    var range = controlMax - controlMin;

    var position = ((controlVal - controlMin) / range) * 140;
    var positionOffset = Math.round(controlThumbWidth * position / 140) - (controlThumbWidth / 2);
    var output = control.next('output');

    output
    .css('left', 'calc(' + position + '% - ' + positionOffset + 'px)')
    .text(controlVal);

});

// step 2
$('#done-btn').click(function(){
    $('#done-btn').addClass('d-none');
    $('#feeling').removeClass('d-none');
    var value = 50;
    $(".track-data").attr("data-percentage", value.toString());
});
$('.mood-set').click(function(){
    var value = 100;
    $(".track-data").attr("data-percentage", value.toString());
    $("#form-error").addClass('d-none');
    $("#form-ok").removeClass('d-none');
    $("#form-error1").addClass('d-none');
    $("#form-ok1").removeClass('d-none');
});



$('#form-ok1').click(function(){
    $('#submit').click();
}); 

// pc submit form

$('#form-ok').click(function(){
    $('#submit').click();
}); 
